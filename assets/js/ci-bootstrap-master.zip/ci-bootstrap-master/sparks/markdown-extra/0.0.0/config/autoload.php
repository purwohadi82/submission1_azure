<?php

# Load the markdown-extra helper
$autoload['helper'] = array('markdown-extra');