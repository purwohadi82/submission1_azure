
<!DOCTYPE html> 
<html lang="es">
<head>

  <meta charset="utf-8">
  <link href="<?php echo base_url(); ?>assets/css/admin/global.css" rel="stylesheet" type="text/css">
  	<link rel="stylesheet" type="text/css" href="<?=base_url();?>assets/css/font-awesome.css">
	<link rel="stylesheet" type="text/css" href="<?=base_url();?>assets/css/menu.css">
	<link rel="stylesheet" type="text/css" href="<?=base_url();?>assets/css/shadowbox.css">
    
	<script type="text/javascript" src="<?=base_url();?>assets/js/jquery.js"></script>
	<script type="text/javascript" src="<?=base_url();?>assets/js/function.js"></script>
	<script type="text/javascript" src="<?=base_url();?>assets/js/shadowbox.js"></script>
	<script type='text/javascript'> 
		Shadowbox.init({ 
		overlayColor: "#000", 
		overlayOpacity: "0.6", 
	}); 
</script> 
</head>
<body>

