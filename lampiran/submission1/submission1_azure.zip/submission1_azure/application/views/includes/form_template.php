<?php $this->load->view('includes/form_header'); ?>

<?php $this->load->view($main_content); ?>

